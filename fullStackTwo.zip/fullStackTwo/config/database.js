// config/database.js
module.exports = {

    'url' : 'mongodb+srv://demo:demo@cluster0.v11xd.mongodb.net/map?retryWrites=true&w=majority',
    'dbName': 'map'
};
