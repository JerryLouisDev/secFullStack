document.querySelector('button').addEventListener('click', parkSearch)

function parkSearch(){
  let search = document.querySelector('[placeholder= "parks"]').value
  
}

function initMap() {

  const options = {
    zoom: 14,
    center: { lat:40.7243, lng: -74.0018}
  }
  var map = new google.maps.Map(document.getElementById("map"), options);

  // New Map

  // add marker
  var marker = new google.maps.Marker({

    position:{ lat:40.7243,lng: -74.0018},
    map:map

  });
  console.log(new google.maps);

  let url = `https://cors-anywhere.herokuapp.com/https://maps.googleapis.com/maps/api/js?key=AIzaSyASSGdDnjFAtZzMUFyQ-k03Sk23SNNDnJg&callback=initMap&libraries=&v=weekly`

  console.log(url);
  fetch(url)
    .then(res => res.json())
    .then(data => {
      console.log(data);
    })

  // {
  //   center: { lat: 42.2771, lng: -71.0914 },
  //   zoom: 14,
  // });
  const request = require('request');

  request(
    {
      url: 'https://api.foursquare.com/v2/venues/explore',
      method: 'GET',
      qs: {
        client_id: '0EIP22C3OKX4Q22BFUQFV0KROYVGN5SN2HLOANCQGJ5MNIFF',
        client_secret: 'WPON4AR2AURBGSDDLQWDV05UN0WEQZSKPRIZLMJUWPKKJWUM',
        ll: '40.7243,-74.0018',
        query: 'coffee',
        v: '20180323',
        limit: 1,
      },
    },
    function(err, res, body) {
      if (err) {
        console.error(err);
      } else {
        console.log(body);
      }
    }
  );

}






// document.querySelector('button').addEventListener('click', run);
// let select = document.getElementsByTagName('button');
//
// function initMap() {
//   var options = {
//     zoom: 8,
    // center: {
    //   lat: 42.3601,
    //   lng: -71.0589
    // }
//   }
//   var map = new google.maps.Map(document.getElementById('map') options);
// }
//
// for (let i = 0; i < select.length; i++) {
//   select[i].addEventListener('click', () => {
//     console.log("do the fetch for ", select[i].id);
//
// let url = `https://maps.googleapis.com/maps/api/js?key=AIzaSyASSGdDnjFAtZzMUFyQ-k03Sk23SNNDnJg&callback=initMap&libraries=&v=weekly`
//
// console.log(url);
// fetch(url)
//   .then(res => res.json())
//   .then(data => {
//     console.log(data);
//   })

// let horoscope = document.querySelector('.horscope').innerHTML = data.horoscope;
// // console.log(data.slip.id)
// let urlAdvice = `https://api.adviceslip.com/advice`
// console.log(urlAdvice);
//
// fetch(urlAdvice)
//   .then(res => res.json())
//   .then(adviceData => {
//     console.log(adviceData);
//     let advice = document.querySelector('.advice').innerHTML = adviceData.slip.advice;
//   })

// })
//
// }

function run() {





}
